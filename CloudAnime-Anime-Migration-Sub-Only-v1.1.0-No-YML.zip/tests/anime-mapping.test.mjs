import fs from 'node:fs'; import vm from 'node:vm'; import test from 'node:test'; import assert from 'node:assert/strict';
const helper=fs.readFileSync('scripts/anime-mapping.js','utf8');
function setup(handler){const box={URL,Promise,setTimeout,clearTimeout};vm.createContext(box);vm.runInContext(helper,box);const calls=[];return {calls,request:box.cloudbankAnimeMappingFetch(async(url,opts)=>{calls.push([url,opts]);return handler(new URL(url),opts);})};}
const reply=(data,status=200)=>({ok:status===200,status,json:async()=>data});
const url='https://id-mapping-api-malid.hf.space/api/resolve?id=tt123&s=2&e=8';
const row=(mal,season=2)=>({myanimelist:mal,anilist:mal+10,imdb:'tt123',themoviedb:77,'themoviedb-season':season,media:'TV'});
const dataset=(mal,episodes)=>({mappings:{mal_id:mal},titles:{en:'Season title'},episodes:Object.fromEntries(episodes.map(([n,date])=>[n,{episode:String(n),airdate:date}]))});
function handler(rows,datasets,videos=[{season:2,episode:8,released:'2024-05-01'}]){return u=>{if(u.hostname==='arm.haglund.dev')return reply(rows);if(u.hostname==='v3-cinemeta.strem.io')return reply({meta:{videos}});if(u.hostname==='api.ani.zip')return reply(datasets[u.searchParams.get('mal_id')],datasets[u.searchParams.get('mal_id')]?200:503);throw Error('unexpected request '+u);};}
test('split season maps requested eighth episode to local first by date',async()=>{const {request,calls}=setup(handler([row(1),row(2)],{1:dataset(1,[[8,'2024-01-01']]),2:dataset(2,[[1,'2024-05-01']])}));const r=await request(url);assert.equal(r.status,200);const m=await r.json();assert.equal(m.mal_id,2);assert.equal(m.mal_episode,1);assert.equal(m.episode,1);assert.ok(calls.every(([u])=>!u.includes('hf.space')));});
test('different season cannot silently select requested episode number',async()=>{const {request}=setup(handler([row(1,1)],{1:dataset(1,[[8,'2024-01-01']])}));assert.equal((await request(url)).status,404);});
test('missing dates, unavailable dataset and ambiguous matches fail safely',async()=>{for(const [rows,data,videos] of [[[row(1)],{1:dataset(1,[[8,'2024-01-01']])},[]],[[row(1)],{},undefined],[[row(1),row(2)],{1:dataset(1,[[1,'2024-05-01']]),2:dataset(2,[[1,'2024-05-01']])},undefined],[[row(1)],{1:dataset(1,[[1,'2024-05-01'],[2,'2024-05-01']])},undefined]]){const {request}=setup(handler(rows,data,videos));assert.equal((await request(url)).status,404);}});
test('same-day double release uses target order',async()=>{const videos=[{season:2,episode:7,released:'2024-05-01'},{season:2,episode:8,released:'2024-05-01'}];const {request}=setup(handler([row(2)],{2:dataset(2,[[1,'2024-05-01'],[2,'2024-05-01']])},videos));assert.equal((await(await request(url)).json()).mal_episode,2);});
test('UTC one-day difference accepted; two days and specials rejected',async()=>{for(const [date,expected]of[['2024-04-30',200],['2024-04-29',404]]){const {request}=setup(handler([row(2)],{2:dataset(2,[[1,date],['S1','2024-05-01']])}));assert.equal((await request(url)).status,expected);}});
test('Anikoto movie route adapts old schema',async()=>{const {request,calls}=setup(()=>reply([{myanimelist:199,anilist:199,themoviedb:129,media:'MOVIE','themoviedb-season':null}]));const m=await(await request('https://arm.haglund.dev/api/v2/tmdb?id=129')).json();assert.equal(m.mal_id,199);assert.equal(m.anilist,199);assert.equal(m.episode,1);assert.equal(calls[0][0],'https://arm.haglund.dev/api/v2/themoviedb?id=129');});
test('TMDB dates override Cinemeta alternative season numbering',async()=>{const base=handler([row(2)],{2:dataset(2,[[1,'2024-05-01']])},[{season:2,episode:8,released:'2023-01-01'}]);const {request}=setup(u=>u.hostname==='api.themoviedb.org'?reply({episodes:[{season_number:2,episode_number:8,air_date:'2024-05-01'}]}):base(u));await request('https://api.themoviedb.org/3/tv/77?api_key=test');assert.equal((await request(url)).status,200);});
test('successful results cache; failures retry; unrelated options unchanged',async()=>{let available=false;const base=handler([row(2)],{2:dataset(2,[[1,'2024-05-01']])});const {request,calls}=setup(u=>u.hostname==='arm.haglund.dev'&&!available?reply({},503):base(u));assert.equal((await request(url)).status,404);available=true;assert.equal((await request(url)).status,200);let count=calls.length;assert.equal((await request(url)).status,200);assert.equal(calls.length,count);const opts={method:'POST',headers:{'X-Test':'yes'}};const f=setup((u,o)=>{assert.equal(o,opts);return reply({ok:true});});await f.request('https://example.com/stream',opts);assert.equal(f.calls.length,1);});
test('six consolidated resolver paths retain exact mapping helper outside upstream boundaries',()=>{
 for(const id of ['hianime','animepahe','anizone','anikototv']){
  const s=fs.readFileSync('providers/'+id+'.js','utf8');
  const start=s.indexOf('/* CLOUDBANK_ANIME_MAPPING_START */\n')+'/* CLOUDBANK_ANIME_MAPPING_START */\n'.length;
  const end=s.indexOf('\n/* CLOUDBANK_ANIME_MAPPING_END */');
  assert.equal(s.slice(start,end),helper.trimEnd(),id);
  assert.ok(end<s.indexOf('/* CLOUDBANK_UPSTREAM_SOURCE_START */'),id);
  if(id==='anizone') assert.ok(s.includes('cloudbankAnimeMappingFetch(cloudbankMergedBudgetFetch(cloudbankMergedMetadataFetch(fetch), deadline))'));
  else assert.ok(s.includes('cloudbankAnimeMappingFetch(cloudbankMetadataFetch(fetch))'));
  if(['hianime','animepahe'].includes(id)) assert.ok(s.includes('cloudbankAnimeMappingFetch(cloudbankMergedBudgetFetch(cloudbankMergedMetadataFetch(fetch), deadline))'));
 }
});
test('Anikoto first TV call resolves numeric ID before any TMDB metadata request',async()=>{const {request}=setup(handler([row(2)],{2:dataset(2,[[1,'2024-05-01']])}));const m=await(await request('https://arm.haglund.dev/api/v2/tmdb?id=77&s=2&e=8')).json();assert.equal(m.mal_id,2);assert.equal(m.episode,1);});
test('real Demon Slayer provider responses match actual payload schema',async()=>{const fixture=JSON.parse(fs.readFileSync('tests/fixtures/anime-mapping-demon-slayer.json'));const {request}=setup(u=>u.hostname==='arm.haglund.dev'?reply([fixture.arm]):u.hostname==='api.ani.zip'?reply(fixture.ani):u.hostname==='api.themoviedb.org'?reply(fixture.tmdb):reply({meta:{videos:[]}}));await request('https://api.themoviedb.org/3/tv/85937?api_key=test');const m=await(await request('https://id-mapping-api-malid.hf.space/api/resolve?id=tt9335498&s=1&e=1')).json();assert.equal(m.mal_id,38000);assert.equal(m.mal_episode,1);});
test('verified mapping title resolves MAL title without fragile redundant Jikan request',async()=>{const {request,calls}=setup(handler([row(2)],{2:dataset(2,[[1,'2024-05-01']])}));await request(url);let count=calls.length;const m=await(await request('https://api.jikan.moe/v4/anime/2')).json();assert.equal(m.data.title,'Season title');assert.equal(m.data.mal_id,2);assert.equal(calls.length,count);});
test('all six actual upstream resolvers reach source lookup after repaired TV mapping',async()=>{
 const {createRequire}=await import('node:module');const require=createRequire(import.meta.url);
 const fixture=JSON.parse(fs.readFileSync('tests/fixtures/anime-mapping-demon-slayer.json'));
 for(const id of ['hianime','hianime-v2','animepahe','animepahe-v2','anizone-v2','anikototv']) {
  const requests=[];
  const tmdb={id:85937,name:'Demon Slayer: Kimetsu no Yaiba',first_air_date:'2019-04-06',original_language:'ja',origin_country:['JP'],genres:[{id:16,name:'Animation'}],external_ids:{imdb_id:'tt9335498'},seasons:[{season_number:1,episode_count:26}]};
  const box={module:{exports:{}},console:{log(){},warn(){},error(){}},AbortController,Headers,URL,URLSearchParams,Promise,setTimeout,clearTimeout,atob,btoa,require,
   fetch:async(url,options)=>{const u=new URL(url);requests.push(u);let data={data:[]},body='';
    if(u.hostname==='arm.haglund.dev')data=[fixture.arm];
    else if(u.hostname==='api.ani.zip')data=fixture.ani;
    else if(u.hostname==='v3-cinemeta.strem.io')data={meta:{videos:[{season:1,episode:1,released:'2019-04-06'}]}};
    else if(u.hostname==='api.themoviedb.org')data=u.pathname.endsWith('external_ids')?{imdb_id:'tt9335498'}:u.pathname.endsWith('episode/1')?{name:'Cruelty',air_date:'2019-04-06',runtime:24}:u.pathname.endsWith('season/1')?fixture.tmdb:tmdb;
    body=JSON.stringify(data);
    return {ok:true,status:200,headers:{get(){return 'application/json';}},json:async()=>data,text:async()=>u.hostname==='anizone.to'?'':body};
   }};
  box.globalThis=box;box.global=box;box.VUEO_DISCOVERY_CONTEXT={tmdb};vm.createContext(box);vm.runInContext(fs.readFileSync('providers/'+id.replace(/-v2$/, '')+'.js','utf8'),box);
  const provider=id.endsWith('-v2')?box.cloudbankMergedEngines.find(e=>e.id===id).provider:box.module.exports;
  await provider.getStreams('85937','tv',1,1);
  assert.ok(requests.some(u=>id.startsWith('animepahe')?/animepahe/.test(u.hostname):id==='anizone-v2'?u.hostname==='anizone.to':u.hostname==='megaplay.buzz'),id+' should reach source host: '+requests.map(u=>u.href).join(', '));
  assert.ok(!requests.some(u=>u.hostname==='id-mapping-api-malid.hf.space'||u.pathname==='/api/v2/tmdb'||u.hostname==='api.jikan.moe'),id+' should use verified mapping and title');
 }
});

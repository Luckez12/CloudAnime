/* CLOUDANIME_TITLE_FALLBACK_V1: embedded in standalone providers; no runtime imports. */
function cloudAnimeTitleKey(value) {
  var s = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (s.normalize) s = s.normalize('NFKC');
  var ordinals = {second:2,third:3,fourth:4,fifth:5,sixth:6,seventh:7,eighth:8,ninth:9,tenth:10};
  s = s.replace(/\b(second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/g, function(_, n) {return 'season '+ordinals[n];})
    .replace(/\b(\d+)(?:st|nd|rd|th)\s+season\b/g, 'season $1')
    .replace(/第\s*(\d+)\s*期/g, 'season $1');
  // Do not strip numbers, part/cour labels or sequel suffixes.
  return s.replace(/[^a-z0-9\u00c0-\uffff]/g, '');
}
async function cloudAnimeTitleFallback(id, type, season, episode, deadline) {
  id=String(id); type=type==='series'?'tv':type; season=Number(season); episode=type==='movie'?1:Number(episode);
  if (!/^(?:tt\d+|[1-9]\d*)$/.test(id) || !['tv','movie'].includes(type) ||
      type==='tv'&&(!Number.isInteger(season)||season<1||!Number.isInteger(episode)||episode<1)) return null;
  // Leave time for the existing extractor; never extend its deadline.
  var until=Math.min(Date.now()+7000,typeof deadline==='number'?deadline-2500:Infinity), calls=0;
  if (until<=Date.now()) return null;
  async function bounded(work, limit) {
    var timer;
    try { return await Promise.race([Promise.resolve().then(work),new Promise(function(_,reject){timer=setTimeout(function(){reject(Error('Title fallback timeout'));},Math.max(1,Math.min(limit,until-Date.now())));})]); }
    finally { clearTimeout(timer); }
  }
  async function request(url, options) {
    if (Date.now()>=until) throw Error('Title fallback budget exhausted');
    var controller=typeof AbortController==='function'?new AbortController():null, timer;
    options=Object.assign({},options||{});options.headers=Object.assign({Accept:'application/json'},options.headers||{});
    if(controller) options.signal=controller.signal;
    calls++;
    try {
      return await Promise.race([
        Promise.resolve().then(function(){return fetch(url,options);}).then(async function(r){
          if(!r.ok)throw Error('Catalogue HTTP '+r.status);
          var body=await r.text();if(body.length>1500000)throw Error('Catalogue response too large');return JSON.parse(body);
        }),
        new Promise(function(_,reject){timer=setTimeout(function(){if(controller)controller.abort();reject(Error('Catalogue timeout'));},Math.max(1,Math.min(3000,until-Date.now())));})
      ]);
    } finally { clearTimeout(timer); }
  }
  function positive(n){return Number.isInteger(Number(n))&&Number(n)>0?Number(n):null;}
  function read(value){if(typeof value==='string')try{return JSON.parse(value);}catch(_){return null;}return value;}
  function compatible(ctx){
    if(!ctx||typeof ctx!=='object')return false;
    var d=ctx.tmdb||ctx, ref=ctx.tmdbId!=null?ctx.tmdbId:d.id;
    if(/^tt/.test(id)){if(String(ctx.imdbId||d.imdb_id||d.external_ids&&d.external_ids.imdb_id||'')!==id)return false;}
    else if(String(ref)!==id)return false;
    var kind=ctx.mediaType||ctx.type;
    return (!kind||kind===type||kind==='series'&&type==='tv')&&(!d.original_language||d.original_language==='ja');
  }
  function namesFor(n){
    var key=cloudAnimeTitleKey(n);
    if(!key)return [];
    if(type==='movie'||season===1)return [key];
    // A later requested season never accepts an unsuffixed first-season title.
    var numbered=/season(\d+)$/.exec(key);
    if(numbered)return Number(numbered[1])===season?[key]:[];
    return [cloudAnimeTitleKey(n+' Season '+season)];
  }
  function match(c, keys){
    if(!positive(c.mal)||!c.names.some(function(n){return keys.indexOf(cloudAnimeTitleKey(n))>=0;}))return false;
    if(type==='movie'?c.format!=='MOVIE':['TV','TV_SHORT','ONA'].indexOf(c.format)<0)return false;
    if(c.country!=='JP'&&!c.jikan)return false;
    return true;
  }
  try {
    var ctx=read(typeof globalThis!=='undefined'&&globalThis.VUEO_DISCOVERY_CONTEXT);
    if(!compatible(ctx)&&typeof globalThis.vueoDiscoveryContext==='function'&&!/^tt/.test(id))
      ctx=read(await bounded(function(){return globalThis.vueoDiscoveryContext('https://api.themoviedb.org/3/'+type+'/'+id);},2000));
    if(!compatible(ctx))return null;
    var d=ctx.tmdb||ctx, names=[d.name,d.title,d.original_name,d.original_title].concat(ctx.aliases||[]);
    var alt=d.alternative_titles||{};(alt.titles||alt.results||[]).forEach(function(x){if(x)names.push(x.title);});
    names=names.filter(function(n,i,a){return typeof n==='string'&&n.trim()&&a.indexOf(n)===i;});
    var keys=[];names.forEach(function(n){namesFor(n).forEach(function(k){if(keys.indexOf(k)<0)keys.push(k);});});
    if(!keys.length)return null;
    var queries=names.filter(function(n){return namesFor(n).length;}).slice(0,2).map(function(n){
      return type==='tv'&&season>1&&!/season\d+$/.test(cloudAnimeTitleKey(n))?n+' Season '+season:n;
    });
    queries=queries.filter(function(q,i,a){return a.indexOf(q)===i;});
    console.log('[CloudAnime] TITLE_FALLBACK: mapping unavailable; exact title/season search; '+queries.length+' queries');
    var query='query($search:String!){Page(perPage:25){pageInfo{hasNextPage} media(search:$search,type:ANIME){id idMal countryOfOrigin format episodes title{english romaji native} synonyms}}}';
    var candidates=[], catalogueFailed=false, incomplete=false;
    var results=await Promise.all(queries.map(async function(q){
      try {
        var r=await request('https://graphql.anilist.co',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:query,variables:{search:q}})});
        var page=r&&r.data&&r.data.Page;
        if(!page||!Array.isArray(page.media))throw Error('Invalid anime catalogue');
        if(page.pageInfo&&page.pageInfo.hasNextPage){incomplete=true;return [];}
        return page.media.filter(Boolean).map(function(m){var t=m.title||{};return {mal:positive(m.idMal),ani:positive(m.id),country:m.countryOfOrigin,format:m.format,count:positive(m.episodes),names:[t.english,t.romaji,t.native].concat(m.synonyms||[])};});
      } catch(_){catalogueFailed=true;return [];}
    }));
    if(incomplete)return null;
    // Do not select a partial result set when one alias search was unavailable.
    if(catalogueFailed){
      if(d.original_language!=='ja')return null;
      var j=await request('https://api.jikan.moe/v4/anime?q='+encodeURIComponent(queries[0])+'&limit=25');
      if(!j||!Array.isArray(j.data)||j.pagination&&j.pagination.has_next_page)return null;
      candidates=j.data.filter(Boolean).map(function(m){return {mal:positive(m.mal_id),ani:null,country:null,jikan:true,format:String(m.type||'').toUpperCase().replace(/ /g,'_'),count:positive(m.episodes),names:[m.title,m.title_english,m.title_japanese].concat(m.title_synonyms||[],(m.titles||[]).map(function(t){return t.title;}))};});
    }else results.forEach(function(items){candidates=candidates.concat(items);});
    candidates=candidates.filter(function(c){return match(c,keys);});
    var unique=Object.create(null);candidates.forEach(function(c){var old=unique[c.mal];if(old&&old.ani&&c.ani&&old.ani!==c.ani)throw Error('Conflicting catalogue IDs');unique[c.mal]=c;});
    candidates=Object.keys(unique).map(function(k){return unique[k];});
    if(candidates.length!==1){console.log('[CloudAnime] TITLE_FALLBACK: exact candidates='+candidates.length+'; skipped');return null;}
    var chosen=candidates[0];
    if(chosen.count&&episode>chosen.count)return null;
    if(!chosen.ani){
      var zip=await request('https://api.ani.zip/mappings?mal_id='+chosen.mal),m=zip&&zip.mappings;
      if(!m||Number(m.mal_id)!==chosen.mal||!positive(m.anilist_id))return null;
      chosen.ani=Number(m.anilist_id);
    }
    var aliases=chosen.names.filter(function(n,i,a){return typeof n==='string'&&n.trim()&&a.indexOf(n)===i;}),title=aliases.find(function(n){return keys.indexOf(cloudAnimeTitleKey(n))>=0;});
    var value={mal_id:chosen.mal,anilist:chosen.ani,mal_episode:episode,episode:episode,anime_title:title,titles:aliases,expectedEpisodes:chosen.count,animeplanet_slug:'',mapping_method:'exact-title-season-fallback',title_fallback:true};
    console.log('[CloudAnime] TITLE_FALLBACK: unique MAL '+value.mal_id+' / AniList '+value.anilist+'; episode '+episode+'; '+calls+' HTTP calls');
    return value;
  }catch(error){console.log('[CloudAnime] TITLE_FALLBACK: unavailable; '+error.message);return null;}
}
async function cloudAnimeRecoverMapping(original, id, type, season, episode, deadline) {
  try {var mapped=await original();if(mapped)return mapped;}
  catch(error){
    // A known conflict is not a missing identity and must never be overridden.
    if(/conflict|disagree|mismatch|overlap/i.test(String(error&&error.message)))throw error;
  }
  return cloudAnimeTitleFallback(id,type,season,episode,deadline);
}
/* CLOUDANIME_TITLE_FALLBACK_END */

/* CloudAnime Reanime v2.0.5 — direct identity route; requires VUEO provider HLS instructions v1. */
(function () {
  "use strict";
  var SITE = "https://reanime.to",
    FLIX = "https://flixcloud.cc";
  var UA =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
  var documents = Object.create(null),
    documentKeys = [];
  function log(stage, text) {
    console.log("[Reanime] " + stage + ": " + text);
  }
  function positive(v) {
    var n = Number(v);
    return Number.isInteger(n) && n > 0 ? n : null;
  }
  function day(v) {
    return typeof v === "string" && /^\d{4}-\d{2}-\d{2}/.test(v)
      ? v.slice(0, 10)
      : "";
  }
  function address(u, base) {
    try {
      var x = new URL(u, base);
      return x.protocol === "https:" ? x.href : "";
    } catch (_) {
      return "";
    }
  }
  function host(u) {
    try {
      return new URL(u).hostname;
    } catch (_) {
      return "";
    }
  }
  function flixHost(u) {
    return /^(?:[a-z0-9-]+\.)*flixcloud\.cc$/i.test(host(u));
  }
  function attribute(line, key) {
    var m = new RegExp("(?:[:,])" + key + '=(?:"([^"]*)"|([^,]*))', "i").exec(
      line,
    );
    return m ? (m[1] != null ? m[1] : m[2]) : "";
  }
  function japanese(line) {
    return /^(ja|jpn|japanese)$/i.test(attribute(line, "LANGUAGE"));
  }
  function decodeTable(input) {
    var nodes = (input && input.nodes) || [],
      found = null;
    nodes.forEach(function (node) {
      if (!node || !Array.isArray(node.data)) return;
      var table = node.data,
        memo = Object.create(null),
        count = 0;
      function get(i, depth) {
        if (i === -1) return undefined;
        if (
          !Number.isInteger(i) ||
          i < 0 ||
          i >= table.length ||
          depth > 30 ||
          ++count > 15000
        )
          throw Error("Invalid embed data");
        if (Object.prototype.hasOwnProperty.call(memo, i)) return memo[i];
        var v = table[i],
          out;
        if (Array.isArray(v)) {
          out = [];
          memo[i] = out;
          v.forEach(function (n) {
            out.push(get(n, depth + 1));
          });
          return out;
        }
        if (v && typeof v === "object") {
          out = Object.create(null);
          memo[i] = out;
          Object.keys(v).forEach(function (k) {
            out[k] = get(v[k], depth + 1);
          });
          return out;
        }
        return (memo[i] = v);
      }
      if (
        table[0] &&
        typeof table[0] === "object" &&
        Object.prototype.hasOwnProperty.call(table[0], "w_payload")
      )
        found = get(0, 0);
    });
    return found;
  }
  function bytes(C, wa) {
    var out = new Uint8Array(wa.sigBytes);
    for (var i = 0; i < out.length; i++)
      out[i] = (wa.words[i >>> 2] >>> (24 - (i % 4) * 8)) & 255;
    return out;
  }
  function words(C, ba) {
    var a = [];
    for (var i = 0; i < ba.length; i++)
      a[i >>> 2] = (a[i >>> 2] || 0) | (ba[i] << (24 - (i % 4) * 8));
    return C.lib.WordArray.create(a, ba.length);
  }
  function base64(C, s) {
    return bytes(C, C.enc.Base64.parse(s));
  }
  function pbkdf(C, password, salt) {
    var suffix = C.lib.WordArray.create([1], 4),
      u = C.HmacSHA256(C.enc.Utf8.parse(salt).concat(suffix), password),
      out = bytes(C, u);
    for (var round = 1; round < 1000; round++) {
      u = C.HmacSHA256(u, password);
      var b = bytes(C, u);
      for (var j = 0; j < 32; j++) out[j] ^= b[j];
    }
    return words(C, out);
  }
  function fields(C, seed) {
    var e = seed;
    for (var i = 0; i < 3; i++) e = C.SHA256(e + i).toString();
    var l = e;
    for (i = 0; i < 3; i++) l = C.SHA256(l + i).toString();
    return {
      kf: "kf_" + e.slice(8, 16),
      iv: "ivf_" + e.slice(16, 24),
      container: "cd_" + e.slice(24, 32),
      array: "ad_" + e.slice(32, 40),
      object: "od_" + e.slice(40, 48),
      token: e.slice(48, 64) + "_" + e.slice(56, 64),
      kf2: l.slice(0, 16) + "_" + l.slice(16, 24),
    };
  }
  function decodePlaylist(C, body, key) {
    if (body.trim().indexOf("#EXTM3U") === 0) return body.trim();
    var b = base64(C, body.trim());
    for (var i = 0; i < b.length; i++) b[i] ^= key[i % key.length];
    var text = words(C, b).toString(C.enc.Utf8);
    if (text.indexOf("#EXTM3U") !== 0) throw Error("Invalid decoded HLS");
    return text;
  }
  function subtitleLanguage(v) {
    v = String(v || "")
      .split(/[([]/, 1)[0]
      .trim()
      .toLowerCase();
    if (/^(?:en|eng|english)$/.test(v)) return "en";
    if (/^(?:ms|msa|may|malay|bahasa melayu)$/.test(v)) return "ms";
    if (/^(?:id|ind|indo|indonesian|bahasa indonesia)$/.test(v)) return "id";
    return "";
  }
  async function getStreams(id, type, season, episode) {
    type = type === "series" ? "tv" : type;
    id = String(id || "");
    if (!/^(?:\d+|tt\d+)$/.test(id) || ["tv", "movie"].indexOf(type) < 0)
      return [];
    if (
      type === "tv" &&
      (!Number.isInteger(Number(season)) ||
        Number(season) < 0 ||
        !positive(episode))
    )
      return [];
    season = Number(season);
    episode = type === "movie" ? 1 : Number(episode);
    var deadline = Date.now() + 18000,
      closed = false,
      requestCount = 0,
      streams = [];
    async function text(url, headers) {
      var left = Math.min(6500, deadline - Date.now());
      if (left <= 0 || closed) throw Error("Request budget reached");
      var timer,
        controller =
          typeof AbortController === "function" ? new AbortController() : null;
      requestCount++;
      try {
        return await Promise.race([
          Promise.resolve()
            .then(function () {
              return fetch(url, {
                headers: Object.assign(
                  {
                    "User-Agent": UA,
                    Accept: "application/json, text/plain, */*",
                  },
                  headers || {},
                ),
                signal: controller ? controller.signal : undefined,
              });
            })
            .then(async function (r) {
              if (!r.ok) {
                var err = Error("HTTP " + r.status + " at " + host(url));
                err.status = r.status;
                throw err;
              }
              var b = await r.text();
              if (b.length > 2000000) throw Error("Response too large");
              return b;
            }),
          new Promise(function (_, reject) {
            timer = setTimeout(function () {
              if (controller) controller.abort();
              reject(Error("HTTP timeout at " + host(url)));
            }, left);
          }),
        ]);
      } finally {
        clearTimeout(timer);
      }
    }
    async function json(url, headers) {
      return JSON.parse(await text(url, headers));
    }
    async function metadata(url) {
      var hit = documents[url];
      if (hit && Date.now() - hit.time < 300000) return hit.data;
      var data = await json(url);
      documents[url] = { time: Date.now(), data: data };
      documentKeys.push(url);
      while (documentKeys.length > 12) delete documents[documentKeys.shift()];
      return data;
    }
    async function mapping() {
      var rows = await metadata(
        "https://arm.haglund.dev/api/v2/" +
          (/^tt/.test(id) ? "imdb" : "themoviedb") +
          "?id=" +
          encodeURIComponent(id),
      );
      if (!Array.isArray(rows)) return null;
      rows = rows.filter(function (r) {
        return (
          r &&
          positive(r.anilist) &&
          (/^tt/.test(id) ? r.imdb === id : String(r.themoviedb) === id) &&
          (type === "movie" ? r.media === "MOVIE" : r.media !== "MOVIE")
        );
      });
      var exact = rows.filter(function (r) {
        return (
          r["themoviedb-season"] != null &&
          Number(r["themoviedb-season"]) === season
        );
      });
      if (type === "movie") {
        var movies = rows.filter(function (r) {
          return r["themoviedb-season"] == null;
        });
        if (movies.length === 1)
          return {
            id: Number(movies[0].anilist),
            ep: 1,
            method: "exact movie ID",
          };
        return null;
      }
      // ARM is the season identity authority. No blanket date gate for a unique normal season.
      if (season > 0 && exact.length === 1)
        return {
          id: Number(exact[0].anilist),
          ep: episode,
          method: "exact season ID",
        };
      var candidates = exact.length
        ? exact
        : rows.filter(function (r) {
            return r["themoviedb-season"] == null;
          });
      // Candidate count is not a matching rule. Filter evidence before network work.
      var candidateSeen = Object.create(null);
      candidates = candidates.filter(function (r) {
        if (
          r["themoviedb-season"] == null ||
          r["thetvdb-season"] == null ||
          Number(r["themoviedb-season"]) !== season ||
          Number(r["thetvdb-season"]) !== season ||
          !positive(r.thetvdb)
        )
          return false;
        var key = [r.anilist, r.thetvdb, Number(r["thetvdb-season"])].join(":");
        if (candidateSeen[key]) return false;
        candidateSeen[key] = true;
        return true;
      });
      if (!candidates.length) {
        log(
          "MAPPING",
          "No explicit ARM season-order bridge for requested season",
        );
        return null;
      }
      var tmdb = positive(id) || positive(candidates[0].themoviedb);
      if (!tmdb) return null;
      // VUEO's metadata-only broker does not provide episode details here.
      // Do not request TMDB episodes or mistake a series-shaped body for one.
      var datasetById = Object.create(null),
        ids = [];
      candidates.forEach(function (r) {
        var key = String(r.anilist);
        if (ids.indexOf(key) < 0) ids.push(key);
      });
      // Bound concurrency, never discard candidates solely because there are many.
      for (var offset = 0; offset < ids.length; offset += 4) {
        await Promise.all(
          ids.slice(offset, offset + 4).map(async function (key) {
            datasetById[key] = await metadata(
              "https://api.ani.zip/mappings?anilist_id=" + key,
            ).catch(function () {
              return null;
            });
          }),
        );
      }
      var datasets = candidates.map(function (r) {
        return datasetById[String(r.anilist)];
      });
      var matches = [],
        seenMatches = Object.create(null);
      datasets.forEach(function (d, i) {
        var r = candidates[i];
        // This bridge is allowed only when ARM explicitly equates the two season numbers.
        // Never assume TVDB ordering equals TMDB ordering for an unlinked season.
        if (
          r["themoviedb-season"] == null ||
          r["thetvdb-season"] == null ||
          Number(r["themoviedb-season"]) !== season ||
          Number(r["thetvdb-season"]) !== season ||
          !positive(r.thetvdb)
        )
          return;
        if (
          !d ||
          !d.mappings ||
          Number(d.mappings.anilist_id) !== Number(r.anilist) ||
          String(d.mappings.themoviedb_id) !== String(tmdb) ||
          Number(d.mappings.thetvdb_id) !== Number(r.thetvdb)
        )
          return;
        Object.keys(d.episodes || {}).forEach(function (key) {
          var e = d.episodes[key];
          if (
            !e ||
            !positive(e.episode) ||
            e.seasonNumber == null ||
            e.episodeNumber == null ||
            Number(e.tvdbShowId) !== Number(r.thetvdb) ||
            Number(e.seasonNumber) !== season ||
            Number(e.episodeNumber) !== episode
          )
            return;
          var matchKey = r.anilist + ":" + Number(e.episode);
          if (seenMatches[matchKey]) return;
          seenMatches[matchKey] = true;
          matches.push({
            id: Number(r.anilist),
            ep: Number(e.episode),
            method: "ARM linked season + AniZip exact episode",
          });
        });
      });
      if (matches.length !== 1)
        log(
          "MAPPING",
          "Linked episode candidates=" +
            matches.length +
            "; no safe TMDB episode metadata fallback",
        );
      return matches.length === 1 ? matches[0] : null;
    }
    async function extract(embed, mapped, server) {
      var u = new URL(embed);
      if (!flixHost(embed) || u.hostname !== "flixcloud.cc") return;
      var m = /^\/e\/([a-z0-9]+)$/i.exec(u.pathname);
      if (!m) return;
      var profile = u.searchParams.get("v");
      if (profile && !/^\d{1,2}$/.test(profile)) return;
      var data = decodeTable(
        await json(
          FLIX +
            "/e/" +
            m[1] +
            "/__data.json" +
            (profile ? "?v=" + profile : ""),
          {
            Referer: SITE + "/",
          },
        ),
      );
      if (
        !data ||
        typeof data.obfuscation_seed !== "string" ||
        data.obfuscation_seed.length > 128
      )
        throw Error("Missing playback metadata");
      var C = require("crypto-js"),
        f = fields(C, data.obfuscation_seed),
        o = data.obfuscated_crypto_data[f.container][f.array][0][f.object],
        token = data[f.token];
      if (typeof token !== "string" || !/^[a-zA-Z0-9_-]{1,512}$/.test(token))
        throw Error("Invalid playback token");
      var tok = await json(FLIX + "/api/m3u8/" + token, {
          Referer: FLIX + "/",
        }),
        frag = base64(C, o[f.kf]),
        frag2 = base64(C, data[f.kf2]),
        T = base64(
          C,
          tok[
            C.SHA256(token + "key")
              .toString()
              .slice(0, 10)
          ],
        );
      if (frag.length !== 32 || frag2.length !== 32 || T.length !== 32)
        throw Error("Unsupported key lengths");
      var kernel = flixKernel(base64(C, data.w_payload));
      kernel.memory.set(frag, 1000);
      kernel.memory.set(frag2, 1032);
      kernel.memory.set(T, 1064);
      kernel.run("_s", [parseInt(data.obfuscation_seed.slice(0, 8), 16) | 0]);
      kernel.run("_r", [1000, 1032, 1064, 1096, 32]);
      var key = pbkdf(
          C,
          words(C, kernel.memory.slice(1096, 1128)),
          data.obfuscation_seed,
        ),
        kb = bytes(C, key);
      for (var i = 0; i < 32; i++)
        kb[i] ^= data.obfuscation_seed.charCodeAt(
          i % data.obfuscation_seed.length,
        );
      var aesKey = C.SHA256(words(C, kb)),
        url = C.AES.decrypt(
          {
            ciphertext: C.enc.Base64.parse(
              tok[
                C.SHA256(token + "vid")
                  .toString()
                  .slice(0, 10)
              ],
            ),
          },
          aesKey,
          {
            iv: C.enc.Base64.parse(o[f.iv]),
            mode: C.mode.CBC,
            padding: C.pad.Pkcs7,
          },
        )
          .toString(C.enc.Utf8)
          .trim();
      if (
        !flixHost(url) ||
        !/^https:\/\//.test(url) ||
        !/\.m3u8$/.test(new URL(url).pathname) ||
        !/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i.test(
          new URL(url).pathname,
        )
      )
        throw Error("Invalid stream URL");
      var ptr = kernel.run("_c", []),
        manifestKey = kernel.memory.slice(ptr, ptr + 32),
        headers = { "User-Agent": UA, Referer: FLIX + "/", Origin: FLIX };
      var master = decodePlaylist(C, await text(url, headers), manifestKey);
      if (master.indexOf("#EXT-X-STREAM-INF:") < 0)
        throw Error("Master HLS not published");
      var audio = master.split(/\r?\n/).filter(function (l) {
        return (
          /^#EXT-X-MEDIA:/.test(l) &&
          attribute(l, "TYPE").toUpperCase() === "AUDIO"
        );
      });
      if (
        (audio.length && !audio.some(japanese)) ||
        (!audio.length && data.audio_type !== "sub")
      )
        throw Error("Japanese HLS audio not verified");
      var tracks = (data.subtitles || [])
        .map(function (t) {
          var lang = subtitleLanguage(t.language),
            src = address(t.url);
          return lang && src
            ? {
                url: src,
                language: lang,
                name:
                  lang === "en" ? "English" : lang === "ms" ? "Malay" : "Indo",
                mimeType:
                  t.format === "ass"
                    ? "text/x-ssa"
                    : t.format === "srt"
                      ? "application/x-subrip"
                      : "text/vtt",
                format: t.format,
                headers: headers,
              }
            : null;
        })
        .filter(Boolean);
      if (closed) return;
      var fragment =
        "vueo_hls_v1=base64-xor&key=" +
        words(C, manifestKey).toString(C.enc.Hex) +
        "&audio=ja,jpn,japanese" +
        "&segment_prefixes=52494646????????57454250,89504e470d0a1a0a" +
        "&segment_key=9d2af147b38e5c70a619e43bd8620fc5&segment_plain=47";
      var source = {
        name: "Reanime / " + server + " (Auto)",
        serverName: server,
        title:
          "AniList " +
          mapped.id +
          " • Episode " +
          mapped.ep +
          " • Japanese Sub",
        url: url + "#" + fragment,
        headers: headers,
        quality: "Auto",
        type: "hls",
        mimeType: "application/x-mpegURL",
        audioLanguage: "ja",
        subtitles: tracks,
        provider: "reanime",
      };
      log(
        "EXTRACT",
        "master HLS verified; Japanese rendition; " +
          tracks.length +
          " subtitle tracks; provider HLS instructions v1",
      );
      return source;
    }
    try {
      var mapped = await (async function() {
        var value = await cloudAnimeRecoverMapping(function() { return mapping(); }, id, type, season, episode, deadline);
        if (!value || !value.title_fallback) return value;
        return {id:value.anilist, ep:value.episode, method:value.mapping_method,
          titleFallback:value, slugHint:value.animeplanet_slug};
      })();
      if (!mapped) {
        log("MAPPING", "No unambiguous title/episode mapping; skipped");
        return [];
      }
      log(
        "MAPPING",
        "AniList " +
          mapped.id +
          ", episode " +
          mapped.ep +
          " via " +
          mapped.method,
      );
      var res = await json(SITE + "/api/flix/" + mapped.id + "/" + mapped.ep, {
        Referer: SITE + "/",
      });
      if (!res.success || !Array.isArray(res.servers)) {
        log("RESULT", "No published servers");
        return [];
      }
      var seen = Object.create(null);
      var servers = res.servers
        .filter(function (server) {
          if (
            !server ||
            String(server.dataType).toLowerCase() !== "sub" ||
            !server.dataLink
          )
            return false;
          var url = address(server.dataLink);
          if (!url || !flixHost(url)) return false;
          // The profile query distinguishes HD-1 and HD-2 even for a shared access ID.
          var identity = JSON.stringify([url, server.serverName || ""]);
          if (seen[identity]) return false;
          seen[identity] = true;
          return true;
        })
        .slice(0, 6);
      var results = [];
      for (var batch = 0; batch < servers.length; batch += 2) {
        var pair = await Promise.all(
          servers.slice(batch, batch + 2).map(async function (server) {
            try {
              return await extract(
                server.dataLink,
                mapped,
                server.serverName || "FlixCloud",
              );
            } catch (e) {
              log(
                "EXTRACT",
                (server.serverName || "FlixCloud") +
                  ": " +
                  String(e.message).replace(/https?:\/\/\S+/g, "<url>"),
              );
              return null;
            }
          }),
        );
        results = results.concat(pair);
      }
      streams = results.filter(Boolean);
    } catch (e) {
      log("RESULT", String(e.message).replace(/https?:\/\/\S+/g, "<url>"));
    } finally {
      closed = true;
      log(
        "RESULT",
        streams.length + " sources, " + requestCount + " HTTP calls",
      );
    }
    return streams;
  }
  /* Bounded interpreter for the site's small i32-only key module; no eval or WebAssembly required. */
  function flixKernel(bytes) {
    if (
      bytes.length < 8 ||
      bytes.length > 16384 ||
      bytes[0] !== 0 ||
      bytes[1] !== 97 ||
      bytes[2] !== 115 ||
      bytes[3] !== 109 ||
      bytes[4] !== 1
    )
      throw Error("Invalid key module");
    var p = 8,
      types = [],
      funcs = [],
      exports = {},
      bodies = [],
      globals = [0],
      memory = new Uint8Array(65536);
    function leb(signed) {
      var v = 0,
        shift = 0,
        b;
      do {
        if (p >= bytes.length || shift > 35) throw Error("Invalid key module");
        b = bytes[p++];
        v |= (b & 127) << shift;
        shift += 7;
      } while (b & 128);
      return signed && shift < 32 && b & 64 ? v | (-1 << shift) : v;
    }
    function str() {
      var n = leb(),
        s = "";
      while (n--) s += String.fromCharCode(bytes[p++]);
      return s;
    }
    while (p < bytes.length) {
      var section = bytes[p++],
        size = leb(),
        end = p + size;
      if (end > bytes.length) throw Error("Invalid key module");
      if (section === 1) {
        for (var n = leb(); n--; ) {
          if (bytes[p++] !== 96) throw Error("Unsupported key type");
          var a = leb();
          for (var j = 0; j < a; j++)
            if (bytes[p++] !== 127) throw Error("Unsupported key type");
          var r = leb();
          for (j = 0; j < r; j++)
            if (bytes[p++] !== 127) throw Error("Unsupported key result");
          types.push({ args: a, results: r });
        }
      } else if (section === 2) {
        if (leb()) throw Error("Imported key module rejected");
      } else if (section === 3) {
        for (n = leb(); n--; ) funcs.push(leb());
      } else if (section === 7) {
        for (n = leb(); n--; ) {
          var name = str(),
            kind = bytes[p++],
            index = leb();
          if (kind === 0) exports[name] = index;
        }
      } else if (section === 10) {
        for (n = leb(); n--; ) {
          var len = leb(),
            stop = p + len,
            locals = 0;
          for (var groups = leb(); groups--; ) {
            locals += leb();
            if (bytes[p++] !== 127) throw Error("Unsupported local");
          }
          if (locals > 64) throw Error("Key local limit");
          var ops = [],
            open = [];
          while (p < stop) {
            var op = bytes[p++],
              ins = { op: op };
            if (op === 2 || op === 3) {
              if (bytes[p++] !== 64) throw Error("Unsupported block");
              open.push(ops.length);
            } else if (op === 11 && open.length) {
              var at = open.pop();
              ops[at].end = ops.length;
            } else if ([12, 13, 32, 33, 34, 35, 36].indexOf(op) >= 0)
              ins.arg = leb();
            else if (op === 65) ins.arg = leb(true);
            else if (op === 45 || op === 58) {
              leb();
              ins.arg = leb();
            } else if (
              [
                11, 15, 26, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 106,
                107, 108, 113, 114, 115, 116, 117, 118, 119, 120,
              ].indexOf(op) < 0
            )
              throw Error("Unsupported key instruction");
            ops.push(ins);
          }
          if (open.length || p !== stop) throw Error("Invalid key function");
          bodies.push({ locals: locals, ops: ops });
        }
      } else if (section === 11) {
        for (n = leb(); n--; ) {
          if (leb() !== 0 || bytes[p++] !== 65)
            throw Error("Unsupported key data");
          var offset = leb(true);
          if (bytes[p++] !== 11) throw Error("Invalid key data");
          len = leb();
          if (offset < 0 || offset + len > memory.length)
            throw Error("Key memory bounds");
          memory.set(bytes.slice(p, p + len), offset);
          p += len;
        }
      }
      p = end;
    }
    function run(name, args) {
      var f = exports[name],
        body = bodies[f],
        sig = types[funcs[f]];
      if (!body || !sig || args.length !== sig.args)
        throw Error("Missing key export");
      var l = args.concat(Array(body.locals).fill(0)),
        s = [],
        frames = [],
        pc = 0,
        steps = 0;
      function pop() {
        if (!s.length) throw Error("Key stack underflow");
        return s.pop() | 0;
      }
      function address(off) {
        var a = (pop() >>> 0) + off;
        if (a >= memory.length) throw Error("Key memory bounds");
        return a;
      }
      function branch(depth) {
        var at = frames.length - 1 - depth,
          f = frames[at];
        if (!f) throw Error("Invalid key branch");
        if (f.loop) {
          frames.length = at + 1;
          pc = f.start + 1;
        } else {
          frames.length = at;
          pc = f.end + 1;
        }
      }
      while (pc < body.ops.length) {
        if (++steps > 50000) throw Error("Key instruction budget");
        var i = body.ops[pc++],
          o = i.op,
          a,
          b;
        if (o === 2 || o === 3) {
          frames.push({ start: pc - 1, end: i.end, loop: o === 3 });
          continue;
        }
        if (o === 11) {
          if (frames.length) frames.pop();
          else break;
          continue;
        }
        if (o === 12) {
          branch(i.arg);
          continue;
        }
        if (o === 13) {
          if (pop()) branch(i.arg);
          continue;
        }
        if (o === 15) break;
        if (o === 32) {
          s.push(l[i.arg] | 0);
          continue;
        }
        if (o === 33) {
          l[i.arg] = pop();
          continue;
        }
        if (o === 34) {
          a = pop();
          l[i.arg] = a;
          s.push(a);
          continue;
        }
        if (o === 35) {
          s.push(globals[i.arg] | 0);
          continue;
        }
        if (o === 36) {
          globals[i.arg] = pop();
          continue;
        }
        if (o === 65) {
          s.push(i.arg);
          continue;
        }
        if (o === 26) {
          pop();
          continue;
        }
        if (o === 45) {
          s.push(memory[address(i.arg)]);
          continue;
        }
        if (o === 58) {
          a = pop();
          memory[address(i.arg)] = a & 255;
          continue;
        }
        if (o === 69) {
          s.push(pop() === 0 ? 1 : 0);
          continue;
        }
        b = pop();
        a = pop();
        if (o === 106) a = a + b;
        else if (o === 107) a = a - b;
        else if (o === 108) a = Math.imul(a, b);
        else if (o === 113) a = a & b;
        else if (o === 114) a = a | b;
        else if (o === 115) a = a ^ b;
        else if (o === 116) a = a << b;
        else if (o === 117) a = a >> b;
        else if (o === 118) a = a >>> b;
        else if (o === 119) a = (a << b) | (a >>> (32 - b));
        else if (o === 120) a = (a >>> b) | (a << (32 - b));
        else if (o === 70) a = a === b;
        else if (o === 71) a = a !== b;
        else if (o === 72) a = a < b;
        else if (o === 73) a = a >>> 0 < b >>> 0;
        else if (o === 74) a = a > b;
        else if (o === 75) a = a >>> 0 > b >>> 0;
        else if (o === 76) a = a <= b;
        else if (o === 77) a = a >>> 0 <= b >>> 0;
        else if (o === 78) a = a >= b;
        else if (o === 79) a = a >>> 0 >= b >>> 0;
        else throw Error("Unsupported key operation");
        s.push(a | 0);
      }
      return sig.results ? pop() : 0;
    }
    return { memory: memory, run: run };
  }

  module.exports = { getStreams: getStreams };
  if (typeof globalThis !== "undefined") globalThis.getStreams = getStreams;
})();

/* CLOUDANIME_MINIMUM_RESOLUTION_V1: standalone in every provider; no app changes or HTTP probes. */
function cloudAnimeResolutionHeight(stream) {
  function height(value, bare) {
    if (typeof value === 'number') return isFinite(value) && value > 0 ? value : null;
    if (typeof value !== 'string') return null;
    var text = value.trim(), match = /(?:^|[^0-9])(\d{2,5})\s*[x×]\s*(\d{2,5})(?![0-9])/i.exec(text);
    if (match) return +match[2];
    match = /(?:^|[^a-z0-9])(\d{2,5})\s*[pi](?=$|[^a-z0-9])/i.exec(text);
    if (match) return +match[1];
    if (bare && /^\d{2,5}$/.test(text)) return +text;
    if (bare && /^(?:sd|standard[ -]definition)$/i.test(text)) return 480;
    if (bare && /^(?:hd|fhd|full[ -]?hd|uhd|[248]k)$/i.test(text)) return 720;
    return null;
  }
  if (!stream || typeof stream !== 'object') return null;
  // Published dimensions take priority over broad display labels.
  var value = height(stream.height, true);
  if (value !== null) return value;
  var fields = ['resolution', 'quality', 'sourceQuality', 'qualityLabel'];
  for (var i = 0; i < fields.length; i++) {
    value = height(stream[fields[i]], true);
    if (value !== null) return value;
  }
  // Only explicit resolution syntax in labels/files; never infer from URL IDs,
  // episode numbers, file sizes or bitrate. Auto/Unknown alone remain allowed.
  var labels = ['name', 'title', 'fileName', 'filename'];
  var context = typeof globalThis !== 'undefined' && globalThis.VUEO_DISCOVERY_CONTEXT;
  var tmdb = context && context.tmdb || {};
  var titles = [tmdb.title, tmdb.name, tmdb.original_title, tmdb.original_name, context && context.title];
  for (var j = 0; j < labels.length; j++) {
    var label = typeof stream[labels[j]] === 'string' ? stream[labels[j]] : '';
    titles.forEach(function(title) { if (typeof title === 'string' && title) label = label.split(title).join(''); });
    value = height(label, false);
    if (value !== null) return value;
  }
  return null;
}
function cloudAnimeMinimumResolution(streams, providerId) {
  if (!Array.isArray(streams)) return streams;
  var rejected = 0;
  var result = streams.filter(function(stream) {
    var height = cloudAnimeResolutionHeight(stream);
    if (height !== null && height < 720) { rejected++; return false; }
    return true;
  });
  if (rejected && typeof console !== 'undefined' && console.log) {
    console.log('[CloudAnime][' + providerId + '] QUALITY_FILTER: rejected ' + rejected + ' below 720p; Auto/Unknown allowed');
  }
  return result;
}
function cloudAnimeInstallMinimumResolution(provider, providerId) {
  if (!provider || typeof provider.getStreams !== 'function') return provider;
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function() {
    var args = arguments, receiver = this;
    return Promise.resolve().then(function() { return original.apply(receiver, args); })
      .then(function(streams) { return cloudAnimeMinimumResolution(streams, providerId); });
  };
  return adapted;
}
/* CLOUDANIME_MINIMUM_RESOLUTION_END */

module.exports = cloudAnimeInstallMinimumResolution(module.exports, "reanime");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
